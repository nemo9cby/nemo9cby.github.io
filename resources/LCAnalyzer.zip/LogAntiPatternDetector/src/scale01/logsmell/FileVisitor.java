package scale01.logsmell;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Expression;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.InfixExpression;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.ReturnStatement;

import com.google.common.collect.Sets;
import com.google.common.collect.Sets.SetView;



public class FileVisitor extends ASTVisitor{
	
	HashMap<String, String> methodReturnMap = new HashMap<>();
	
	
	public FileVisitor() 
	{
		super();
	}
	
	public boolean visit (ReturnStatement node)
	{
		ASTNode curNode = node;
		while (curNode.getNodeType() != ASTNode.METHOD_DECLARATION)
		{
			curNode = curNode.getParent();
		}
		
		String returnExp = node.getExpression().toString();
		MethodDeclaration mdNode = (MethodDeclaration) curNode;
		methodReturnMap.put(returnExp, mdNode.toString());
		return false;
	}
	
	
	@Override
	public boolean visit(ExpressionStatement node) 
	{
		ArrayList<ASTNode> upperNode = new ArrayList<>();
		
		ASTNode curNode = node;
		while (curNode.getNodeType() != ASTNode.METHOD_DECLARATION)
		{
			curNode = curNode.getParent();
			upperNode.add(curNode);
		}
		MethodDeclaration mdNode = (MethodDeclaration) curNode;
		IfCheckVisitor ifCheckVisitor = new IfCheckVisitor();
		mdNode.accept(ifCheckVisitor);
		if (LogUtility.ifLogPrinting(node.toString()))
		{
			HashMap<String, ArrayList<String>> argumentContents = new HashMap<>();
			LogMethodVisitor lmv = new LogMethodVisitor(argumentContents);
			node.accept(lmv);
			argumentContents = lmv.getArgumentContents();
			
			// rules with method invocation
			if (argumentContents.containsKey("MethodInvocation"))
			{
				ArrayList<String> mi = argumentContents.get("MethodInvocation");
				for (String s: mi)
				{
					for (String key: methodReturnMap.keySet())
					{
						List<String> originalMISplit = Arrays.asList(s.split("\\."));
						List<String> keySplit = Arrays.asList(key.split("\\."));
						SetView<String> result = Sets.intersection(Sets.newHashSet(originalMISplit), Sets.newHashSet(keySplit));
						if (result.size() > 0)
							System.out.println("yee");
					}
				}
			}
			
			if (argumentContents.containsKey("SimpleName"))
			{
				
			}
		}
		return false;
	}
	
	class IfCheckVisitor extends ASTVisitor
	{
		ArrayList<String> ifExps = new ArrayList<>();
		public boolean visit (IfStatement ifNode)
		{
			Expression exp = ifNode.getExpression();
			ifExps.add(exp.toString());
			return true;
		}
	}
	
	class LogMethodVisitor extends ASTVisitor{
		
		private HashMap<String, ArrayList<String>> argumentContents;
		
		public LogMethodVisitor(HashMap<String, ArrayList<String>> argumentContents) {
			super();
			this.argumentContents = argumentContents;
		}
		
		public boolean visit(MethodInvocation mi)
		{
			List arguments = mi.arguments();
			if (arguments.size() > 1) {
				for (int i = 0; i < arguments.size(); i ++)
				{
					Object obj = arguments.get(i);
					if (obj instanceof InfixExpression)
					{
						InfixExpression ex = (InfixExpression) obj;
						if(ex.getOperator().toString().equals("+"))
							recursiveInfixExpression(ex);
						else
							objectTypeChoose(obj);
					} else 
					{
						objectTypeChoose(obj);
					}
				}
			} else if(arguments.size() == 1)
			{
				if (arguments.get(0) instanceof InfixExpression)
				{
					InfixExpression ex = (InfixExpression) arguments.get(0);
					if(ex.getOperator().toString().equals("+"))
						recursiveInfixExpression(ex);
					else
						objectTypeChoose(ex);
				}
				else {
					objectTypeChoose(arguments.get(0));
				}

			}
			return false;
		}
		
		private void recursiveInfixExpression(InfixExpression ex)
		{
			Expression left = ex.getLeftOperand();
			Expression right = ex.getRightOperand();
			List extendedOperands = ex.extendedOperands();
			if (left.getNodeType() == ASTNode.INFIX_EXPRESSION)
			{
				InfixExpression next = (InfixExpression) left;
				if (next.getOperator().toString().equals("+"))
				{
					recursiveInfixExpression(next);
				}
				else{
					expressionTypeChoose(next);
				}
			} 
			else 
			{
				expressionTypeChoose(left);
			}
			if (right.getNodeType() == ASTNode.INFIX_EXPRESSION)
			{
				InfixExpression next = (InfixExpression) right;
				if (next.getOperator().toString().equals("+"))
					recursiveInfixExpression(next);
				else
					expressionTypeChoose(next);
			}
			else 
			{
				expressionTypeChoose(right);
			}
			
			for (int i = 0; i < extendedOperands.size(); i ++)
			{
				objectTypeChoose(extendedOperands.get(i));
			}
		}
		
		private void expressionTypeChoose(Expression ex)
		{
			String key = ex.getClass().getSimpleName();
			String value = ex.toString();
			if (argumentContents.containsKey(key))
			{
				argumentContents.get(key).add(value);
			} else 
			{
				ArrayList<String> valueList = new ArrayList<>();
				valueList.add(value);
				argumentContents.put(key, valueList);
			}
			
		}
		
		private void objectTypeChoose(Object obj)
		{			
			String key = obj.getClass().getSimpleName();
			String value = obj.toString();
			if (argumentContents.containsKey(key))
			{
				argumentContents.get(key).add(value);
			} else 
			{
				ArrayList<String> valueList = new ArrayList<>();
				valueList.add(value);
				argumentContents.put(key, valueList);
			}

		}
	
		public HashMap<String, ArrayList<String>> getArgumentContents()
		{
			return argumentContents;
		}
	}
}
