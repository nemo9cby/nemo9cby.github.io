package scale01.logsmell;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LogUtility {
	private static String regexGLOBAL = ".*?(log|trace|(system\\.out)|(system\\.err)).*?(.*?);";

	private static boolean isLogRelated(String content)
	{
		if (content.split("\r|\n|\r\n").length >= 3) // set as 3
		{
			return false;
		}
		else
		{
			Pattern p = Pattern.compile(regexGLOBAL, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
			Matcher m = p.matcher(content);
			if (m.find())
			{
				if (content.toLowerCase().contains("system.out") || content.toLowerCase().contains("system.err"))
				{
					return true;
				}
				content = content.replaceAll("\"(.*?)\"", "");
				Pattern pKeyword = Pattern.compile("(login)|(dialog)|(logout)|(catalog)|logic(al)?", Pattern.CASE_INSENSITIVE);
				Pattern pTrueKeyword = Pattern.compile("loginput|logoutput", Pattern.CASE_INSENSITIVE);
				m = pKeyword.matcher(content);
				Matcher m2 = pTrueKeyword.matcher(content);
				if (m.find() && !m2.find())
					return false;
				
				return true;
			}
		}
		return false;
	}
	public static boolean ifLogPrinting(String cur)
	{
		Pattern p = Pattern.compile("\".*\"");
		Matcher m = p.matcher(cur);
		
		if(cur.toLowerCase().contains("assertequals") || cur.toLowerCase().contains("assertfalse") || cur.toLowerCase().contains("asserttrue"))
		{
			return false;
		}
		
		/* if find quotes */
		if (m.find())
		{
			cur = cur.replaceAll("\".*?\"", "");
			if (!isLogRelated(cur))
				return false;
			p = Pattern.compile("[^\"]*?\\=");
			Matcher mEqualSign = p.matcher(cur);
			if (mEqualSign.find())
				return false;
			p = Pattern.compile("(system\\.out)|(system.err)|(log(ger)?(\\(\\))?\\.(\\w*?)\\()|logauditevent\\(",Pattern.CASE_INSENSITIVE);
			m = p.matcher(cur);
			if (m.find())
			{
				return true;
			}
			return false;
		}
		else 
		{
			p = Pattern.compile("[^\"]*?\\=");
			Matcher mEqualSign = p.matcher(cur);
			if (mEqualSign.find())
				return false;
			p = Pattern.compile("(system\\.out)|(system.err)|(log(ger)?(\\(\\))?\\.(\\w*?)\\()",Pattern.CASE_INSENSITIVE);
			m = p.matcher(cur);
			if (m.find())
			{
				return true;
			}
			return false;
		}
	}

	private static int minimum(int a, int b, int c) {                            
        return Math.min(Math.min(a, b), c);                                      
    }                                                                            
                                                                                 
    public static int computeLevenshteinDistance(CharSequence lhs, CharSequence rhs) {      
        int[][] distance = new int[lhs.length() + 1][rhs.length() + 1];        
                                                                                 
        for (int i = 0; i <= lhs.length(); i++)                                 
            distance[i][0] = i;                                                  
        for (int j = 1; j <= rhs.length(); j++)                                 
            distance[0][j] = j;                                                  
                                                                                 
        for (int i = 1; i <= lhs.length(); i++)                                 
            for (int j = 1; j <= rhs.length(); j++)                             
                distance[i][j] = minimum(                                        
                        distance[i - 1][j] + 1,                                  
                        distance[i][j - 1] + 1,                                  
                        distance[i - 1][j - 1] + ((lhs.charAt(i - 1) == rhs.charAt(j - 1)) ? 0 : 1));
                                                                                 
        return distance[lhs.length()][rhs.length()];                           
    }

	public static String getFileString(String path) throws Exception
	{
		BufferedReader reader = new BufferedReader(new FileReader(path));
		String result = "";
		String line = "";
		while ((line = reader.readLine()) != null)
		{
			result = result.concat(line + "\n");
		}
		reader.close();
		return result;
	}
}
