package scale01.logsmell;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.Assignment;
import org.eclipse.jdt.core.dom.CatchClause;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.EnhancedForStatement;
import org.eclipse.jdt.core.dom.ExpressionStatement;
import org.eclipse.jdt.core.dom.IfStatement;
import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.MethodInvocation;
import org.eclipse.jdt.core.dom.ReturnStatement;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.ThrowStatement;
import org.eclipse.jdt.core.dom.TypeDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;
import scale01.generator.afterthought.afterthoughtParser;

public class LogAbstractionWithASTInfo {
	
	ExpressionStatement logNode;
	HashMap<String, ArrayList<ASTNode>> argumentContents;
	ArrayList<ASTNode> parentNodesOfLog = new ArrayList<>();
	String verbosityLevel = "info";
	
	public LogAbstractionWithASTInfo(ExpressionStatement node,
			HashMap<String, ArrayList<ASTNode>> argumentContents) 
	{
		logNode = node;
		this.argumentContents = argumentContents;
		extractLogLevel();
		getParentNodes();
		
	}
	
	public boolean smellCheckTextLevelInConsistency()
	{
		String verbosityRegex = "\\b(debug|info|error|fatal|warn|trace)\\b";
		
		if (argumentContents.containsKey("StringLiteral"))
		{
			Pattern p = Pattern.compile(verbosityRegex,Pattern.CASE_INSENSITIVE);
			for (ASTNode node: argumentContents.get("StringLiteral"))
			{
				String s = node.toString();
				Matcher m = p.matcher(s);
				while (m.find())
				{
//					System.out.println(m.group(1));
					if (m.group(1).toLowerCase().equals("debug"))
					{
						if (this.verbosityLevel.equals("info") ||
							this.verbosityLevel.equals("warn") || 
							this.verbosityLevel.equals("error"))
						{
							return true;
						}
					}
				}			
			}
		}
		return false;
	}
	
	public boolean smellCheckIncludeException()
	{
		for (ASTNode astNode : parentNodesOfLog)
		{	
			if (astNode.getNodeType() == ASTNode.CATCH_CLAUSE)
			{
				CatchClause cc = (CatchClause) astNode;
				String exceptionVar = cc.getException().getName().toString();
				
				if (argumentContents.containsKey("SimpleName"))
				{
					for (ASTNode node : argumentContents.get("SimpleName"))
					{
						String var = node.toString();
						if(var.equals(exceptionVar))
							return true;
					}
				}
				
				if(argumentContents.containsKey("MethodInvocation"))
				{
					for (ASTNode node : argumentContents.get("MethodInvocation"))
					{
						String mi = node.toString();
						
						if (mi.equals("StringUtils.stringifyException(" + exceptionVar+")"))
							return true;
						
						ArrayList<ASTNode> miComponents = new ArrayList<>();
						MethodInvocation miNode = (MethodInvocation) node;
						
						while(miNode.getExpression() != null && miNode.getExpression().getNodeType() == ASTNode.METHOD_INVOCATION )
						{
							miComponents.add(0, miNode.getName());
							miNode = (MethodInvocation) miNode.getExpression();
						}
						// miComponents.add(0, miNode.getExpression());
						
						// miComponents.add(0, miNode.getExpression());
						miComponents.add(0, miNode.getName());
						if (miNode.getExpression() != null)
							miComponents.add(0, miNode.getExpression());
						
						String callerVar = miComponents.get(0).toString();
						if (callerVar.equals(exceptionVar))
							return true;
					}
				}
				return false;
			}
		}
		return true;
	}
	
	public boolean smellCheckExceptionInconsistentText()
	{
		for (ASTNode astNode : parentNodesOfLog)
		{	
			if (astNode.getNodeType() == ASTNode.CATCH_CLAUSE)
			{
				CatchClause cc = (CatchClause) astNode;
				
				String exceptionType = cc.getException().getType().toString();
				String var = cc.getException().getName().toString();
				
				HelperThrowStmtVisitor v = new HelperThrowStmtVisitor();
				cc.accept(v);
				ArrayList<ThrowStatement> throwNodes = v.getThrowNodes();
				
				
					
				
				if (argumentContents.containsKey("StringLiteral"))
				{
					for (ASTNode node : argumentContents.get("StringLiteral"))
					{
						String s = node.toString();
						if (s.toLowerCase().contains("throw"))
						{
							// 1. to see if the variable is throwable
							if (exceptionType.equals("Throwable"))
								break;
							// 2. if it contains later
							if (s.toLowerCase().contains("later"))
								break;
							if (!throwNodes.isEmpty())
								break;
//							boolean throwStmtAfterLog = false;
//							for (ThrowStatement t :throwNodes)
//							{
//								if (t.getStartPosition() > logNode.getStartPosition() + logNode.getLength())
//								{
//									throwStmtAfterLog = true;
//								}
//							}
//							if (throwStmtAfterLog)
//								break;
							
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	
	public boolean smellCheckMIReplaceByVar()
	{
//		ASTNode astNode = parentNodesOfLog.get(parentNodesOfLog.size() - 1);
		boolean checkResult = false;
		for (ASTNode astNode: parentNodesOfLog)
		{
			if (astNode.getNodeType() == ASTNode.METHOD_DECLARATION)
			{
				MethodDeclaration md = (MethodDeclaration) astNode;
				HelperVarDeclareAndAssignVisitor v = new HelperVarDeclareAndAssignVisitor();
				md.accept(v);
				ArrayList<VariableDeclarationFragment> variableDeclareNodes = v.getVarDeclareNodes();
				ArrayList<Assignment> assignmentNodes = v.getAssignmentNodes();
				if (argumentContents.containsKey("MethodInvocation"))
				{
					for (ASTNode node : argumentContents.get("MethodInvocation"))
					{	
						String mi = node.toString();
						String miRemoveToString = mi.replace(".toString()", "");
						for (VariableDeclarationFragment vd : variableDeclareNodes)
						{
							// heuristics, the variable declare/assign should be before the log
							if (logNode.getStartPosition() < vd.getStartPosition())
								continue;
								
							if (vd.getInitializer().toString().replace(".toString()", "").equals(miRemoveToString))
							{
								if (vd.toString().split("\\r?\\n").length < 3)
								{
									System.out.println("********* var declare replace by mi");
									System.out.println(vd);
									System.out.println(mi);
									System.out.println("*********");
									checkResult = true;
								}
							}
						}
						
						for (Assignment a : assignmentNodes)
						{
							// heuristics, the variable declare/assign should be before the log
							if (logNode.getStartPosition() < a.getStartPosition())
								continue;
								
							if (a.getRightHandSide().toString().replace(".toString()", "").equals(miRemoveToString)
									&& a.toString().split("\\r?\\n").length < 3)
							{
								System.out.println("********* var assignment replace by mi");
								System.out.println(a);
								System.out.println(mi);
								System.out.println("*********");
								checkResult = true;
							}
						}
					}
				}
			}
		}
		return checkResult;
	}
	
	
	public boolean smellCheckMIInReturnStmt()
	{
		ASTNode astNode = parentNodesOfLog.get(parentNodesOfLog.size() - 1);
		if (astNode.getNodeType() == ASTNode.COMPILATION_UNIT)
		{
			CompilationUnit cu = (CompilationUnit) astNode;
			HelperReturnStmtVisitor v = new HelperReturnStmtVisitor();
			cu.accept(v);
			ArrayList<ReturnStatement> rsNodes = v.getReturnStmt();
			if (argumentContents.containsKey("MethodInvocation"))
			{
				for (ASTNode node : argumentContents.get("MethodInvocation"))
				{
					String mi = node.toString();
					String miRemoveToString = mi.replace(".toString()", "");
					
					
					
					for (ReturnStatement rs: rsNodes)
					{
						if (rs.getExpression().toString().replace(".toString()", "").equals(miRemoveToString))
						{
							System.out.println(rs);
							System.out.println(mi);
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	
	public boolean smellCheckVarIsNull()
	{
		MethodDeclaration md = findMDFromParentNodes();
		if (md == null)
			return false;
		
		for (int i = 0; i < parentNodesOfLog.size(); i ++)
		{
			ASTNode parent = parentNodesOfLog.get(i);
			
			if (parent.getNodeType() == ASTNode.IF_STATEMENT)
			{
				IfStatement ifStmt = (IfStatement) parent;
				boolean insideElse = false;
				if (ifStmt.getElseStatement() != null)
				{
					if(ifStmt.getElseStatement().toString().contains(logNode.toString()))
						insideElse = true;
				}
				HelperVarDeclareAndAssignVisitor v = new HelperVarDeclareAndAssignVisitor();
				ifStmt.accept(v);
				
				if (argumentContents.containsKey("SimpleName"))
				{
					for (ASTNode node : argumentContents.get("SimpleName"))
					{
						boolean assignedAfter = false;
						for (Assignment a : v.assignmentNodes)
						{
							if (a.getStartPosition() < logNode.getStartPosition())
							{
								if (a.getLeftHandSide().toString().equals(node.toString()))
									assignedAfter = true;
							}
						}
						if (assignedAfter)
							continue;
						String var = node.toString();
						String ifexp = ifStmt.getExpression().toString();
						ifexp = ifexp.replaceAll("\\s", "");
						if (insideElse)
						{
							Pattern p = Pattern.compile("(\\W|^)" + var+"!=null");
							Matcher m = p.matcher(ifexp);
							if (m.find())
							{
								return true;
							}
						} else {
							Pattern p = Pattern.compile("(\\W|^)" + var+"==null");
							Matcher m = p.matcher(ifexp);
							if (m.find())
							{
								return true;
							}
							
							p = Pattern.compile("(\\W|^)" + var+"!=null");
							m = p.matcher(ifexp);
							if (m.find())
							{
								if (ifexp.contains("||"))
									return true;
							}
						}
					}
				}
				return false;
			}
		}
		
//		HelperIfStmtVisitor v = new HelperIfStmtVisitor();
//		md.accept(v);
//		ArrayList<IfStatement> ifnodes = v.getIfStmts();
		
		
		return false;
	}
	
	
	public boolean smellCheckTimeInconsistency()
	{
		boolean containTimeMethod = false;
		for(ArrayList<ASTNode> array : argumentContents.values())
		{
			for (ASTNode node : array)
			{
				String s = node.toString();
				if (s.contains("System.currentTimeMillis()") && !s.contains("1000"))
				{
					containTimeMethod = true;
				}
			}
		}
		if (containTimeMethod)
		{
			if (argumentContents.containsKey("StringLiteral"))
			{
				for (ASTNode node : argumentContents.get("StringLiteral"))
				{
					String s = node.toString();
					s = s.toLowerCase();
					if (s.equals("\"s\""))
						return true;
							
				}
			}
		}
		return false;
	}
	
	public boolean smellCheckVariableTypeByte()
	{
		LocalSymbolVisitor v = new LocalSymbolVisitor();
		
		for (ASTNode astNode : parentNodesOfLog)
		{	
			if (astNode.getNodeType() == ASTNode.METHOD_DECLARATION)
			{
				MethodDeclaration md = (MethodDeclaration) astNode;
//			SymbolVisitor v = new SymbolVisitor();
				md.accept(v);
				break;
			} 
		}
		if (argumentContents.containsKey("SimpleName"))
		{
			for (ASTNode simpleNameNode : argumentContents.get("SimpleName"))
			{
				String s = simpleNameNode.toString();
				for (SingleVariableDeclaration node : v.svd)
				{
					if (node.getName().toString().equals(s))
					{
						if (node.getType().toString().toLowerCase().contains("byte"))
							return true;
					}
				}
				
				for (VariableDeclarationStatement node : v.localVars)
				{
					if (!node.getType().toString().toLowerCase().contains("byte"))
						continue;
					List l = node.fragments();
					for (int i = 0; i < l.size(); i ++)
					{
						VariableDeclarationFragment f = (VariableDeclarationFragment) l.get(i);
						if (f.getName().toString().equals(s))
						{
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	
	public boolean smellCheckTextMIInconsistency()
	{
		if (argumentContents.containsKey("StringLiteral") && argumentContents.containsKey("MethodInvocation"))
		{
			for (ASTNode stringNode : argumentContents.get("StringLiteral"))
			{
				String s = stringNode.toString();
				String[] splitTokens = s.split("\\W+");
				for (String token : splitTokens)
				{
					for (ASTNode miNode : argumentContents.get("MethodInvocation"))
					{
						String mi = miNode.toString();
						String[] splitMITokens = mi.split("\\.");
						for (String miToken : splitMITokens)
						{
							if (miToken.length() == 1)
								continue;
							int distance = LogUtility.computeLevenshteinDistance(token.toLowerCase(), miToken.toLowerCase());
							if (distance == 1)
							{
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	}
	

	public boolean smellCheckMIReturnByte(HashMap<String, Boolean> globalMethodMultipleMatch,
			HashMap<String, String> globalMethodReturnTypeMap
											)
	{
		if( argumentContents.containsKey("MethodInvocation"))
		{
			for (ASTNode node :argumentContents.get("MethodInvocation"))
			{
				ArrayList<ASTNode> miComponents = new ArrayList<>();
				MethodInvocation miNode = (MethodInvocation) node;
				
				while(miNode.getExpression() != null && miNode.getExpression().getNodeType() == ASTNode.METHOD_INVOCATION)
				{
					miComponents.add(0, miNode.getName());
					miNode = (MethodInvocation) miNode.getExpression();
				}
				miComponents.add(0, miNode.getName());
				if (miNode.getExpression() != null)
					miComponents.add(0, miNode.getExpression());
				String lastMethodName = miComponents.get(miComponents.size() - 1).toString();
				if (globalMethodMultipleMatch.containsKey(lastMethodName))
				{
					continue;
				}
				else
				{
					
					String returnType = globalMethodReturnTypeMap.get(lastMethodName);
					if (returnType != null)
					{
						returnType = returnType.toLowerCase();
						if (returnType.contains("byte"))
						{
							System.out.println(miNode + " returns byte!");
							return true;
						}
					}
				}
				
			}
		}
		return false;
	}
	
	public boolean smellCheckLogContainsCast()
	{
		if( argumentContents.containsKey("CastExpression"))
			return true;
		return false;
	}
	
	public boolean smellCheckObjToStringContainMethod(ArrayList<String> allFileList)
	{
		ASTNode astNode = parentNodesOfLog.get(parentNodesOfLog.size() - 1);
		CompilationUnit cuOfCurrentFile;
		cuOfCurrentFile = (CompilationUnit) astNode;
		HelperTypeDeclarationVisitor tdv = new HelperTypeDeclarationVisitor();
		cuOfCurrentFile.accept(tdv);
		ArrayList<TypeDeclaration> tdOfCurrentFile = tdv.getTypeDNodes();
		
		MethodDeclaration md = findMDFromParentNodes();
		LocalSymbolVisitor v = new LocalSymbolVisitor();
		HashMap<String, String> localVarNameClassMap = new HashMap<>();
		if (md != null)
		{
			md.accept(v);
		}
		for (VariableDeclarationStatement node : v.localVars)
		{
			String type = node.getType().toString();
			for (int i = 0; i < node.fragments().size(); i ++)
			{
				VariableDeclarationFragment fragment = (VariableDeclarationFragment) node.fragments().get(i);
				String varName = fragment.getName().toString();
				localVarNameClassMap.put(varName, type);
			}
		}
		
		for (SingleVariableDeclaration node : v.svd)
		{
			String type = node.getType().toString();
			String varName = node.getName().toString();
			localVarNameClassMap.put(varName, type);
		}
		
		if (argumentContents.containsKey("MethodInvocation"))
		{
			for (ASTNode node :argumentContents.get("MethodInvocation"))
			{
				ArrayList<ASTNode> miComponents = new ArrayList<>();
				MethodInvocation miNode = (MethodInvocation) node;
				
				while(miNode.getExpression() != null && miNode.getExpression().getNodeType() == ASTNode.METHOD_INVOCATION)
				{
					miComponents.add(0, miNode.getName());
					miNode = (MethodInvocation) miNode.getExpression();
				}
				miComponents.add(0, miNode.getName());
				if (miNode.getExpression() != null)
					miComponents.add(0, miNode.getExpression());
				
				
				String callerVar = miComponents.get(0).toString();
				if (localVarNameClassMap.containsKey(callerVar))
				{
					String className = localVarNameClassMap.get(callerVar);
					
					for (TypeDeclaration td : tdOfCurrentFile)
					{
						if (td.getName().toString().equals(className))
						{
							for (MethodDeclaration mdOfCurrentFile : td.getMethods())
							{
								if (mdOfCurrentFile.getName().toString().equals("toString"))
								{
									HelperReturnStmtVisitor returnV = new HelperReturnStmtVisitor();
									mdOfCurrentFile.accept(returnV);
									for (ReturnStatement rsNode : returnV.getReturnStmt())
									{
										String rString = rsNode.toString();
										String miWithoutCaller = miNode.toString().replace(callerVar+".", "");
										if (rString.contains(miWithoutCaller))
										{
											if (miWithoutCaller.contains("toString"))
												continue;
											
											String temp = rString.replace(miWithoutCaller, "");
											int count = temp.length() - temp.replace("+", "").length();
											if (count <= 2)
											{
												System.out.println(rsNode + "|||||" +  miNode);
												return true;
											}
										}
//										}
										// boolean allMIInToString = true;
//										for (int i = 1; i < miComponents.size(); i ++)
//										{
//											if (!rString.contains(miComponents.get(i).toString()))
//												allMIInToString = false;
//										}
//										if (allMIInToString)
//										{
//											System.out.println(rsNode + "|||||" +  miNode);
//											return true;
//										}
									}
								}
								
							}
						}
					}
					boolean findRefFile = false;
					for (int i = 0; i < allFileList.size(); i ++)
					{	
						String[] t = allFileList.get(i).split("/");
						if (t[t.length - 1].equals(className+".java"))
						{
							findRefFile = true;
							try {
								ASTParser astParser = ASTParser.newParser(AST.JLS8);
								String fs = LogUtility.getFileString(allFileList.get(i));
								astParser.setSource(fs.toCharArray());
								astParser.setKind(ASTParser.K_COMPILATION_UNIT);
								CompilationUnit cu ;
								cu = (CompilationUnit)astParser.createAST(null);
								HelperReturnStmtVisitor returnV = new HelperReturnStmtVisitor();
								cu.accept(returnV);
								for (ReturnStatement rsNode : returnV.rsNodes)
								{
									
									ASTNode tNode = rsNode;
									while (tNode != null)
									{
										if (tNode.getNodeType() == ASTNode.METHOD_DECLARATION)
											break;
										tNode = tNode.getParent();
									}
									MethodDeclaration tMd = (MethodDeclaration) tNode;
									if (tMd.getName().toString().equals("toString"))
									{
										String rString = rsNode.toString();
										String miWithoutCaller = miNode.toString().replace(callerVar+".", "");
										
										if (miWithoutCaller.contains("toString"))
											continue;
										if (rString.contains(miWithoutCaller))
										{
											String temp = rString.replace(miWithoutCaller, "");
											int count = temp.length() - temp.replace("+", "").length();
											if (count <= 2)
											{
												System.out.println(rsNode + "|||||" +  miNode);
												return true;
											}
										}
									}
								}
							} catch (Exception e){
								e.printStackTrace();
							}
						}
					}
					if (!findRefFile)
					{
						System.out.println(miNode + " CANNOT FIND REFERENCE");
					}
				}
			}
		}
		return false;
	}
	
	public boolean smellCheckLoopVarInLog()
	{
		boolean containLoop = false;
		boolean containVar =false;
		for (ASTNode astNode : parentNodesOfLog)
		{	
//			if (astNode.getNodeType() == ASTNode.FOR_STATEMENT)
//			{
//				ForStatement forNode = (ForStatement) astNode;
//				for (int i = 0; i < forNode.initializers();
//			} 
//			if (astNode.getNodeType() == ASTNode.WHILE_STATEMENT)
//			{
//				WhileStatement node = (WhileStatement) astNode;
//				Expression e = node.getExpression();
//				if (e.getNodeType() == ASTNode.INFIX_EXPRESSION)
//				{
//					
//				}
//			}
			
			if (astNode.getNodeType() == ASTNode.ENHANCED_FOR_STATEMENT)
			{
				containLoop = true;
				
				EnhancedForStatement efs = (EnhancedForStatement) astNode;
				String varName = efs.getParameter().getName().toString();
				for (String k : argumentContents.keySet())
				{
					if (!k.equals("StringLiteral"))
						for (ASTNode v : argumentContents.get(k))
						{
							if (v.toString().contains(varName))
								containVar = true;
						}
				}
//				if (argumentContents.containsKey("SimpleName"))
//				{
//					for(ASTNode s : argumentContents.get("SimpleName"))
//					{
//						if( s.toString().equals(varName))
//							return true;
//					}
//				}
//				if (argumentContents.containsKey("MethodInvocation"))
//				{
//					for(ASTNode s : argumentContents.get("MethodInvocation"))
//					{
//						if( s.toString().contains(varName))
//							return true;
//					}
//				}
			}
		}
		if (!containLoop)
			return true;
		else if (containVar)
		{
			return true;
		} else {
			return false;
		}
	}
	
	private MethodDeclaration findMDFromParentNodes()
	{
		for (ASTNode astNode : parentNodesOfLog)
		{	
			if (astNode.getNodeType() == ASTNode.METHOD_DECLARATION)
			{
				MethodDeclaration md = (MethodDeclaration) astNode;
				return md;
			} 
		}
		return null;
	}
	
	@Override
	public String toString() 
	{	
		return logNode.toString();
	}
	
	private void getParentNodes()
	{
		ASTNode curNode = logNode.getParent();
		while (curNode != null)
		{
			parentNodesOfLog.add(curNode);
			curNode = curNode.getParent();
		}
	}
	
	private void extractLogLevel()
	{
		String verbosityRegex = "(debug|info|error|fatal|warn|trace)";
		if (logNode.getExpression().getNodeType() == ASTNode.METHOD_INVOCATION)
		{
			MethodInvocation mi= (MethodInvocation) logNode.getExpression();
			String levelStr = "";
			try{
				levelStr = mi.getExpression().toString() + mi.getName().toString();
			} catch (NullPointerException e) {
				levelStr = mi.getName().toString();
			}
			Pattern p = Pattern.compile(verbosityRegex,Pattern.CASE_INSENSITIVE);
			Matcher m = p.matcher(levelStr);
			if(m.find())
			{
				this.verbosityLevel = m.group(1);
			} else 
			{
				if(levelStr.contains("System.err"))
					this.verbosityLevel = "error";
				
			}
		}
	}
	
	
	class HelperIfStmtVisitor extends ASTVisitor
	{
		ArrayList<IfStatement> nodes = new ArrayList<>();
		public boolean visit(IfStatement node)
		{
			if (node.getExpression() != null)
				nodes.add(node);
			return true;
		}
		
		public ArrayList<IfStatement> getIfStmts()
		{
			return this.nodes;
		}
	}
	
	class HelperReturnStmtVisitor extends ASTVisitor
	{
		ArrayList<ReturnStatement> rsNodes = new ArrayList<>();
		
		public boolean visit(ReturnStatement rs)
		{
			if (rs.getExpression() != null)
				rsNodes.add(rs);
			return false;
		}
		
		public ArrayList<ReturnStatement> getReturnStmt() 
		{
			return this.rsNodes;
		}
	}

	class HelperVarDeclareAndAssignVisitor extends ASTVisitor
	{
		ArrayList<VariableDeclarationFragment> variableDeclareNodes = new ArrayList<>();
		ArrayList<Assignment> assignmentNodes = new ArrayList<>();
		
		public boolean visit(VariableDeclarationFragment vdf)
		{
			if (vdf.getInitializer() == null)
				return false;
			variableDeclareNodes.add(vdf);
			return false;
		}
		
		public boolean visit(Assignment a)
		{
			assignmentNodes.add(a);
			return false;
		}
		
		public ArrayList<VariableDeclarationFragment> getVarDeclareNodes()
		{
			return variableDeclareNodes;
		}
		
		public ArrayList<Assignment> getAssignmentNodes()
		{
			return assignmentNodes;
		}
	}
	
	class HelperMethodDeclareVisitor extends ASTVisitor
	{
		ArrayList<MethodDeclaration> methodDNodes = new ArrayList<>();
		public boolean visit(MethodDeclaration md)
		{
			methodDNodes.add(md);
			return false;
		}
		
		public ArrayList<MethodDeclaration>  getMethodDeclarationNodes()
		{
			return this.methodDNodes;
		}
	}
	
	class HelperThrowStmtVisitor extends ASTVisitor
	{
		ArrayList<ThrowStatement> throwNodes = new ArrayList<>();
		public boolean visit(ThrowStatement node)
		{
			throwNodes.add(node);
			return false;
		}
		
		public ArrayList<ThrowStatement> getThrowNodes()
		{
			return throwNodes;
		}	
	}
	
	class HelperTypeDeclarationVisitor extends ASTVisitor
	{
		ArrayList<TypeDeclaration> tdNodes = new ArrayList<>();
		public boolean visit(TypeDeclaration node)
		{
			tdNodes.add(node);
			return true;
		}
		
		public ArrayList<TypeDeclaration> getTypeDNodes()
		{
			return tdNodes;
		}
	}
}
