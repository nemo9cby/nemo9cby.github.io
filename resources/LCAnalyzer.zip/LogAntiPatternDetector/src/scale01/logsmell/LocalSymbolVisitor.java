package scale01.logsmell;

import java.util.ArrayList;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
import org.eclipse.jdt.core.dom.VariableDeclarationStatement;

public class LocalSymbolVisitor extends ASTVisitor {
	
	public ArrayList<VariableDeclarationStatement> localVars = new ArrayList<>();
//	public ArrayList<FieldDeclaration> fields = new ArrayList<>();
	public ArrayList<SingleVariableDeclaration> svd = new ArrayList<>();
//	public ArrayList<MethodDeclaration> md = new ArrayList<>();
	
//	public boolean visit(FieldDeclaration node)
//	{
//		fields.add(node);
//		return false;
//	}
	
	public boolean visit(SingleVariableDeclaration node)
	{
		svd.add(node);
		return false;
	}
	
	public boolean visit(VariableDeclarationStatement node) 
	{
		localVars.add(node);
		return false;
	}
	
//	public boolean visit(MethodDeclaration node)
//	{
//		md.add(node);
//		return false;
//	}
	
}
