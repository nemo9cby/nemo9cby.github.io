package scale01.logsmell;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.MethodDeclaration;

import scale01.generator.afterthought.afterthoughtParser;

public class LogSmellDetector {
	static int logID = 0;
	static ArrayList<String> allFiles = new ArrayList<>();
	static HashMap<String, String> globalMethodReturnTypeMap = new HashMap<>();
	static HashMap<String, Boolean> globalMethodMultipleMatch = new HashMap<>();
	public static void main(String[] args) throws Exception {
//		 String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/avro/trunk/src/java/org/apache/avro/ipc/798646|||||SocketTransceiver.java";
		
		// TEST smellCheckTextLevelInConsistency
//		 String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/common/trunk/hadoop-mapreduce-project/hadoop-yarn/hadoop-yarn-server/hadoop-yarn-server-resourcemanager/src/main/java/org/apache/hadoop/yarn/server/resourcemanager/scheduler/fifo/1178631|||||FifoScheduler.java";
		
		// TEST smellCheckIncludeException
		// String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/common/branches/branch-2.4/hadoop-yarn-project/hadoop-yarn/hadoop-yarn-server/hadoop-yarn-server-applicationhistoryservice/src/main/java/org/apache/hadoop/yarn/server/applicationhistoryservice/1578605|||||FileSystemApplicationHistoryStore.java";
		
		// TEST smellCheckMIReplaceByVar
		// String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/hdfs/trunk/src/java/org/apache/hadoop/hdfs/server/datanode/802264|||||DataXceiver.java";
		
		// Test smellCheckMIInReturnStmt
		// String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/avro/trunk/src/java/org/apache/avro/ipc/798646|||||SocketTransceiver.java";
		
		// Test smellCheckVarIsNull
		// String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/common/trunk/hadoop-common-project/hadoop-common/src/main/java/org/apache/hadoop/ipc/1177399|||||RPC.java";
		
		// Test smellCheckExcetionInconsistentText
		// String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/core/trunk/src/mapred/org/apache/hadoop/mapred/684731|||||TaskTracker.java";
		
		// Test smellCheckTimeInconsistency
		// String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/common/trunk/hadoop-mapreduce-project/hadoop-mapreduce-client/hadoop-mapreduce-client-core/src/main/java/org/apache/hadoop/mapreduce/task/reduce/1407118|||||ShuffleScheduler.java";
		
		// Test smellCheckVariableTypeByte
		// String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/hbase/trunk/src/java/org/apache/hadoop/hbase/client/656868|||||HTable.java";
		
		// Test smellCheckTextMIInconsistency
		// String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/hbase/trunk/src/test/org/apache/hadoop/hbase/630605|||||MultiRegionTable.java";
		
		// Test smellCheckLoopVarNotInLog
//		String path = "/Users/nemo/hadoop/hadoop_complete/hadoop/common/trunk/hadoop-common-project/hadoop-auth/src/main/java/org/apache/hadoop/security/authentication/server/1593362|||||KerberosAuthenticationHandler.java";
		
//		String path = "/Users/nemo/hadoop-rel-release-2.7.2/hadoop-hdfs-project/hadoop-hdfs/src/main/java/org/apache/hadoop/hdfs/util/ByteArrayManager.java";
//		try {
//			detect(new File(path));
//		} catch (Exception e) {
//			
//			e.printStackTrace();
//		}
//		
		
//		 Test on a release 
//		String releaseDir = "/Users/nemo/Desktop/bad_log_test_release/apache-maven-3.3.9";
//		String releaseDir = "/Users/nemo/Desktop/bad_log_test_release/activemq-parent-5.14.0";
//		String releaseDir = "/Users/nemo/Desktop/bad_log_test_release/apache-tomcat-8.5.4-src";
//		String releaseDir = "/Users/nemo/Desktop/bad_log_test_release/gwt-2.8.0-rc2";
//		String releaseDir = "/Users/nemo/Desktop/bad_log_test_release/hadoop-rel-release-2.7.2";
//		String releaseDir = "/Users/nemo/Desktop/bad_log_test_release/ArgoUML-0.30.1-src";
//		String releaseDir = args[0];
//		String releaseDir = "/Users/nemo/Desktop/bad_log_test_release/activemq-parent-5.14.0/activemq-kahadb-store/src/main/java/org/apache/activemq/store/kahadb/disk/page/PageFile.java";
//		String releaseDir = "/Users/nemo/hadoop_common_1196902";
//		String releaseDir = "/Users/nemo/activemq_905926/trunk";
//		String releaseDir = "/Users/nemo/maven3_933848";
		
		// String releaseDir = "/Users/nemo/Desktop/bad_log_test_release/hbase-1.2.2";
		String releaseDir = args[0];
		traverse(new File(releaseDir));
		for (int i = 0; i < allFiles.size(); i ++)
		{
			// System.out.println(allFiles.get(i));
			detect(new File(allFiles.get(i)));
		}
//		
		
	}
	
	public static void traverse(File node) throws Exception
	{
		if (node.isFile() && node.getName().endsWith(".java"))
		{
			allFiles.add(node.getAbsolutePath());
			try{
				// parseGlobalMethodInfo(node);
			} catch (Exception e)
			{
				// go on
			}
			
		}
		else if (node.isDirectory()) 
		{
			for (File f : node.listFiles())
			{
				traverse(f);
			}
		}
	}
	
	static void parseGlobalMethodInfo(File node)
	{
		try
		{
			ASTParser astParser = ASTParser.newParser(AST.JLS8);
			String fs = LogUtility.getFileString(node.getAbsolutePath());
			astParser.setSource(fs.toCharArray());
			astParser.setKind(ASTParser.K_COMPILATION_UNIT);
			CompilationUnit cu ;
			cu = (CompilationUnit)astParser.createAST(null);
			cu.accept(new ASTVisitor() {
				public boolean visit (MethodDeclaration md) 
				{
					String mName = md.getName().toString();
					String returnType = md.getReturnType2() == null ? "" : md.getReturnType2().toString();
					if (globalMethodMultipleMatch.containsKey(mName))
					{
						globalMethodMultipleMatch.put(mName, true);
					}
					else
					{
						globalMethodMultipleMatch.put(mName, false);
						globalMethodReturnTypeMap.put(mName, returnType);
					}
					return false;
				}
			});
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
	static void detect(File node) throws Exception 
	{
		ASTParser astParser = ASTParser.newParser(AST.JLS8);
		String fs = LogUtility.getFileString(node.getAbsolutePath());
//		astParser.setResolveBindings(true);
		
		astParser.setKind(ASTParser.K_COMPILATION_UNIT);
//		astParser.setBindingsRecovery(true);
 
//		Map options = JavaCore.getOptions();
//		astParser.setCompilerOptions(options);
// 
//		String unitName = node.getName();
//		astParser.setUnitName(unitName);
// 
//		String[] sources = { "/Users/nemo/hadoop-rel-release-2.7.2" }; 
//		String[] classpath = {"/Library/Java/JavaVirtualMachines/jdk1.7.0_79.jdk/Contents/Home/jre/lib"};
// 
//		astParser.setEnvironment(classpath, sources, new String[] { "UTF-8"}, true);
		astParser.setSource(fs.toCharArray());
 
		CompilationUnit cu;
 
//		if (cu.getAST().hasBindingsRecovery()) {
//			System.out.println("Binding activated.");
//		}

//		CompilationUnit cu ;
//		cu = (CompilationUnit)astParser.createAST(null);
		FindLogVisitor fv;
		
		cu = (CompilationUnit) astParser.createAST(null);
		fv = new FindLogVisitor();
		cu.accept(fv);
		
		for(LogAbstractionWithASTInfo logInfo : fv.getLogList())
		{
			logID ++;
			String methodSig = "";
			boolean failCheck = false;
			for (ASTNode ast : logInfo.parentNodesOfLog)
			{
				
				if (ast.getNodeType() == ASTNode.METHOD_DECLARATION)
				{
					MethodDeclaration md = (MethodDeclaration) ast;
					String returnType = "";
					if (md.getReturnType2() != null)
						returnType = md.getReturnType2().toString();
					// String returnType = 
					
					if (md.parameters() == null)
						methodSig = returnType + " " + md.getName();
					else
						methodSig = returnType + " " + md.getName() + " " + md.parameters();
				}
			}
			
			
			
			System.out.printf("%d|||||%s|||||%s\n%s",logID, node.getAbsolutePath(), methodSig, logInfo);
			if (logInfo.smellCheckTextLevelInConsistency())
			{
				failCheck = true;
				System.out.printf("TextLevelInConsistency Check FAILED!!!\n");
			}	
			
			if (!logInfo.smellCheckIncludeException())
			{
				failCheck = true;
				System.out.printf("IncludeException Check FAILED!!!\n");
			}
//			
//			if (logInfo.smellCheckExceptionInconsistentText())
//			{
//				failCheck = true;
//				System.out.printf("ExceptionInconsistentText Check FAILED!!!\n");
//			}
			
			if (logInfo.smellCheckMIReplaceByVar())
			{
				failCheck = true;
				System.out.printf("MIReplaceByVar Check FAILED!!!\n");
			}
			if (logInfo.smellCheckMIInReturnStmt())
			{
				failCheck = true;
				System.out.printf("MIInReturnStmt Check FAILED!!!\n");
			}
			if (logInfo.smellCheckVarIsNull())
			{
				failCheck = true;
				System.out.printf("CheckVarIsNull Check FAILED!!!\n");
			}
//			if (logInfo.smellCheckTimeInconsistency())
//			{
//				failCheck = true;
//				System.out.printf("TimeInconsistency Check FAILED!!!\n");
//			}
			// Only check local variable & method parameters
			if (logInfo.smellCheckVariableTypeByte())
			{
				failCheck = true;
				System.out.printf("VariableTypeByte Check FAILED!!!\n");
			}
//			if (logInfo.smellCheckTextMIInconsistency())
//			{
//				failCheck = true;
//				System.out.printf("TextMIInconsistency Check FAILED!!!\n");
//			}
			if (!logInfo.smellCheckLoopVarInLog())
			{
				failCheck = true;
				System.out.printf("LoopVarNotInLog Check FAILED!!!\n");
			}
			if (logInfo.smellCheckObjToStringContainMethod(allFiles))
			{
				failCheck = true;
				System.out.printf("ObjectToStringContainMI check FAILED!!!\n");
			}
			
//			if (logInfo.smellCheckMIReturnByte(globalMethodMultipleMatch, globalMethodReturnTypeMap))
//			{
//				failCheck = true;
//				System.out.printf("MIReturnByte check FAILED!!!\n");
//			}
			
			if (logInfo.smellCheckLogContainsCast())
			{
				failCheck = true;
				System.out.println("LogContainsCast check FAILED!!!");
			}
			
			
			
			if (failCheck)
				System.out.println("THIS LOG FAILED CHECK!");
		}
	}
}
